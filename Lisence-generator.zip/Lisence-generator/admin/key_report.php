<?php
include "../include/_session.php";
$month = ['January', 'February', 'March', 'April', 'May', 'June', 'July ', 'August', 'September', 'October', 'November', 'December'];

$short = array('Jan', 'Feb',  'Mar',  'Apr',  'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' );


?>


<!DOCTYPE html>
<html lang="en">

<?php include "include/head.php";?>

<body class="animsition">
   <div class="page-wrapper">
      <!-- HEADER MOBILE-->
      <?php include "include/header_mob.php";?>
      <!-- END HEADER MOBILE-->

      <!-- MENU SIDEBAR-->
      <?php include "include/menu.php";?>
      <!-- END MENU SIDEBAR-->

      <!-- PAGE CONTAINER-->
      <div class="page-container">
         <!-- HEADER DESKTOP-->
         <?php include "include/header.php";?>
         <!-- HEADER DESKTOP-->

         <!-- MAIN CONTENT-->
         <div class="main-content">
            <div class="section__content section__content--p30">
               <div class="container-fluid">
                  <div class="card" style="margin-bottom:10px;">
                     <h5 class="card-header"
                        style="padding-bottom:.8rem;    font-family: 'Prosto One', cursive;">Key Report
                     </h5>
                     <?php
                        $string=exec('getmac');
                        $mac=substr($string, 0, 17); 
                        // echo $mac;
                        ?>
                     <div class="card-body">
                        <form action="report_process.php" method="post">
                           <div class="row">
                              <div class="mb-3 col-md-6" style="display:flex;place-items: center;column-gap: 15px;" id="logmonth">
                                <div style="width:100%">

                                   <label for="firstName" class="form-label">From Date</label>
                                   <input type="date" class="form-control" placeholder="Enter Company Name"
                                            style="    width: 100%;  " id="d1" name="fd"  >
                              </div> 
                              <div style="width:100%">
                              <label for="firstName" class="form-label">To Date</label>
                              <input type="date" class="form-control" placeholder="Enter Company Name"
                                            style="    width: 100%;  " id="d2" name="td"  >
                                 </div>
                              </div>
                                 <div class="mb-3 col-md-6" style="display:flex;place-items: end;column-gap: 15px;" id="logmonth">
                                <div style="width:100%">
                                <label for="firstName" class="form-label">Mode Of Date Report</label>
                                   <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="d3" name="md">
                                    <option value="" disabled selected hidden>Select Mode</option>
                                    <option value="1" >Generated</option>
                                    <option value="2" >Expired</option>
                                    
                                 </select>
                              </div>
                                    <button class="btn btn-primary me-2" name="d_key_report" style="margin-right:1% ; margin-bottom:5px;" id = "g3">Generate Report</button>
                                 </div>
                              </div>
                           </form>

                        <form action="report_process.php" method="post">
                           <div class="row">
                              <div class="mb-3 col-md-6" style="display:flex;place-items: center;column-gap: 15px;" id="logmonth">
                                <div style="width:100%">

                                   <label for="firstName" class="form-label">Month</label>
                                   <select class="form-control"style="    width: 100%;  margin-bottom:5px;" id="m1" name="km">
                                    
                                   <option value="" disabled selected hidden>Select month</option>
                                   <?php for($i = 0; $i<count($month); $i++){?>
                                    <option value="<?php echo $short[$i];?>"><?php echo $month[$i];?></option>
                                    <?php } ?>
                                 </select>
                              </div> 
                              <div style="width:100%">
                              <label for="firstName" class="form-label">Year</label>
                                 <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="y1" name="ky">
                                    <option value="" disabled selected hidden>Select Year</option>
                                    <?php for($i = date("Y"); $i>=2020; $i--){?>
                                       <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                              </div>
                                 <div class="mb-3 col-md-6" style="display:flex;place-items: end;column-gap: 15px;" id="logmonth">
                                <div style="width:100%">
                                <label for="firstName" class="form-label">Mode Of Month Report</label>
                                   <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="s2" name="md1">
                                    <option value="" disabled selected hidden>Select Mode</option>
                                    <option value="1" >Generated</option>
                                    <option value="2" >Expired</option>
                                    
                                 </select>
                              </div>
                                    <button class="btn btn-primary me-2" name="m_key_report" style="margin-right:1% ; margin-bottom:5px;" id = "g1">Generate Report</button>
                                 </div>
                              </div>
                           </form>

                           <form action="report_process.php" method="post">
                           <div class="row">
                           <div class="mb-3 col-md-6" style="display:flex;place-items: center;column-gap: 15px;" id="logmonth">
                              <div style="width:100%">

                                 <label for="firstName" class="form-label" style="margin-right:2.5%;">Form Year</label>
                                 <select class="form-control" placeholder="Enter Month"
                                 style="    width: 100%;  margin-bottom:5px;" id="y3" name="fy">
                                 
                                 <option value="" disabled selected hidden>Select from Year</option>
                                 <?php for($i = date("Y"); $i>=2020; $i--){?>
                                    <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php } ?>
                                 </select>
                              </div>  
                              <div style="width:100%">
                                 <label for="firstName" class="form-label" style="margin-right:2.5%;">To Year</label>
                                 
                                 <select class="form-control" placeholder="Enter Month"
                                 style="    width: 100%;  margin-bottom:5px;" id="y4" name="ty">
                                 <option value="" disabled selected hidden>Select to Year</option>
                                 <?php for($i = date("Y"); $i>=2020; $i--){?>
                                    <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php } ?>
                                 </select>
                              </div>
                           </div>
                           <div class="mb-3 col-md-6" style="display:flex;place-items: end;column-gap: 15px;" id="logmonth">
                              <div style="width:100%">
                                 <label for="firstName" class="form-label" style="margin-right:2.5%;">Mode Of Year Report </label>
                                 <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="y5" name="md2">
                                    <option value="" disabled selected hidden>Select Mode</option>
                                    <option value="1" >Generated</option>
                                    <option value="2" >Expired</option>
                                    
                                 </select>
                              </div>      
                                    <button class="btn btn-primary me-2" name="y_key_report" style="margin-right:1% ; margin-bottom:5px;" id = "g2">Generate Report</button>
                           </div>
                        </div>
                     </form>
                     </div>
                  </div>
               </div>
            </div>

               <!-- END MAIN CONTENT-->
               <!-- END PAGE CONTAINER-->


               <?php include "include/footer.php";?>
</body>


</html>
<!-- end document-->
<script>
   $("#g1").prop("disabled", true);
   $("#g2").prop("disabled", true);
   $("#g3").prop("disabled", true);
   $("#d1, #d2, #d3").change(function(){
      $("#y3").val('');
      $("#y4").val('');
      $("#y5").val('');
      $("#m1").val('');
      $("#y1").val('');
      $("#s2").val('');
      $("#g2").prop("disabled", true);
      $("#g1").prop("disabled", true);
      let v1 = "", v2="", v3="";
      v1 = new Date($('#d1').val());
      v2 = new Date($('#d2').val());
      v3 = new Date($('#d3').val());
      if(v1.getDate()!="NaN" && v2.getDate()!="NaN" && v3.getDate()!="NaN"){
         $("#g3").prop("disabled", false);

      }
   })
   $("#m1, #y1, #s2").change(function(){
      $("#y3").val('');
      $("#y4").val('');
      $("#y5").val('');
      $("#d1").val('');
      $("#d2").val('');
      $("#d3").val('');
      $("#g2").prop("disabled", true);
      $("#g3").prop("disabled", true);
      let v1 = "", v2="", v3="";
      v1 = $("#m1").val();
      v2 = $("#y1").val();
      v3 = $("#s2").val();
      if(v1!=null && v2!=null && v3!=null){
         $("#g1").prop("disabled", false);

      }
   })
   $("#y3, #y4, #y5").change(function(){
      $("#m1").val('');
      $("#y1").val('');
      $("#s2").val('');
      $("#d1").val('');
      $("#d2").val('');
      $("#d3").val('');
      $("#g1").prop("disabled", true);
      $("#g3").prop("disabled", true);
      let v1 = "", v2="", v3="";
      v1 = $("#y3").val();
      v2 = $("#y4").val();
      v3 = $("#y5").val();
      if(v1!=null && v2!=null && v3!=null){
         $("#g2").prop("disabled", false);

      }
   })
</script>