<?php
date_default_timezone_set('Asia/Calcutta');
    $get_c_id=$_POST['slt_client'];
    $get_date=$_POST['date_lic'];
        $t_1 = substr($get_date, 8, 2);    //days
        $t_2 = substr($get_date, 5,2); //month
        $t_3 = substr($get_date, 0, 4); //year
        $temp_date_arrange=$t_1."-".$t_2."-".$t_3;
    $arrange_date= date("d-M-Y",strtotime($temp_date_arrange)); //Final Date


    // $get_mac_1=strtoupper($_POST['mac_1']);
    // $get_mac_2=strtoupper($_POST['mac_2']);
    // $get_mac_3=strtoupper($_POST['mac_3']);
    // $get_mac_4=strtoupper($_POST['mac_4']);
    // $get_mac_5=strtoupper($_POST['mac_5']);
    // $get_mac_6=strtoupper($_POST['mac_6']);
    // $get_mc=$get_mac_1."-".$get_mac_2."-".$get_mac_3."-".$get_mac_4."-".$get_mac_5."-".$get_mac_6;
    $get_mc=
    $code_date=date("dmY");
    $mac=$get_mac_1.$get_mac_2.$get_mac_3.$get_mac_4.$get_mac_5.$get_mac_6;
    $get_year=substr($get_date, 0, 4);
    $get_month=substr($get_date, 5, 2);
    $get_day=substr($get_date, 8, 2);

    $code=substr($mac, 0, 2).substr($get_day, 0, 1).substr($mac, 2, 1).substr($get_day, 1, 1).substr($mac, 3, 2).substr($get_month, 0, 1).substr($mac, 5, 1).substr($get_month, 1, 1).substr($mac, 6, 2).substr($get_year, 0, 1).substr($mac, 8, 1).substr($get_year, 1, 1).substr($mac, 9, 2).substr($get_year, 2, 1).substr($mac, 11, 1).substr($get_year, 3, 1);

     $lic_key=substr($code, 0, 5)."-".substr($code, 5, 5)."-".substr($code, 10, 5)."-".substr($code, 15, 5);

     $enc_key=md5(md5($lic_key));

//      $sql_lic_info=mysqli_query($con, "select * from lic");
//      $sql_lic_info_row=mysqli_num_rows($sql_lic_info);
//      if($sql_lic_info_row==0)
//         $lic_id="LIC1";
//     else
//     {
//         for ($i=1; $i <= $sql_lic_info_row ; $i++) { 
//             # code...
//             $sql_lic_info_array=mysqli_fetch_array($sql_lic_info);
//         }
//         $temp=substr($sql_lic_info_array['lic_id'], 0, 3);
//         $temp_1=substr($sql_lic_info_array['lic_id'], 3, 1)+1;
//         $lic_id=$temp.$temp_1;
//     }

//     mysqli_query($con, "insert into lic (lic_id, client_id, mac_id, valid_date, license_key, enc_key, status) values('$lic_id', '$get_c_id', '$get_mc', '$arrange_date', '$lic_key', '$enc_key', 'Active') ");


?>