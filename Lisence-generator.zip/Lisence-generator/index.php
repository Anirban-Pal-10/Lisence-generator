<?php
include "include/_db_connect.php";
date_default_timezone_set("Asia/Calcutta");
$current_date=date("d-M-Y");
$current_time=date("H:i:s");
$current_month = date("M");
$current_Year = date("Y");
$current_date_time=$current_date." - ".$current_time;

if(isset($_POST['log_submit'])){
 $u_id= $_POST['logid'];
 $pass = $_POST['pwd'];
 $exists_sql= mysqli_query($conn, "select * from `user_details` where `user_id`='$u_id'");
 $no_of_data  =mysqli_num_rows($exists_sql);
 $user_data = mysqli_fetch_assoc($exists_sql);
 if($no_of_data == 1){
   $db_pass= $user_data['password'];
   $user_id = $user_data['user_id'];

  if(password_verify($pass, $db_pass)){
    $user_sts = $user_data['Status'];

    if($user_sts == 'Active'){
      $user_role = $user_data['type'];

      if($user_role == 'Admin'){

        session_start();
        // $_SESSION['user_name'] =  $user_data['user_name'];
        // $_SESSION['name'] = $user_data['name'];
        $_SESSION['user_id'] = $user_id; 
        $_SESSION['loged_in'] = true;
    
        //insert into log table
        $no_of_logs = mysqli_num_rows(mysqli_query($conn,"select * from `log_book`"));
        $log_uid = "LOG-".($no_of_logs+1).'-'.date('mysh');

        $log_sql=mysqli_query($conn,"insert into `log_book`(`uid`, `user_id`, `login_date`, `login_time`,`log_month`,`log_year`) values ('$log_uid','$user_id',CURDATE(),'$current_time','$current_month','$current_Year')");
        if($log_sql){
          $_SESSION['log_id']=$log_uid;
          header("location:admin");
        }
       
      }
    }else{
      session_start();
      $_SESSION['icon'] = 'info';
      $_SESSION['status']='De-Active Account';
    }

  }else{
    session_start();
    $_SESSION['icon'] = 'error';
    $_SESSION['status']='Invalid Password';
  }
 }else{
  session_start();
  $_SESSION['icon'] = 'error';
  $_SESSION['status']='Invalid Login Cradential';
}
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <link rel="stylesheet" href="css/main1.css">
    <title>Activation Key</title>
    <link rel="icon" href="img/logo.png" type="image/icon type">
    <script src="admin/js/sweetalert2.js"></script>
</head>
<body>
    <header style="background-image: url('img/bg.jpg');background-repeat: no-repeat; background-size: cover;	opacity: 0.6;">
    
  </header>
  <div class="login-box">
    <h1>Sign In
      <span class="span1"></span></h1>
    <form action="" method="post">
      <div class="text-box">
        <i class="fa fa-user"></i>
        <input type="text" name="logid" placeholder="Log ID" oninput="this.value = this.value.toUpperCase()" require autofocus>
        <span class="span2"></span>
      </div>
      <div class="text-box">
        <i class="fa fa-lock"></i>
        <input type="password" name="pwd" placeholder="Password" require>
        <span class="span3"></span>

      </div>
      <div class="btn-box">
        <input class="btn" type="submit" name="log_submit" value="LOGIN">
        <span class="span_1"></span>
        <span class="span_2"></span>
        <span class="span_3"></span>
        <span class="span_4"></span>  
      </div>
    </form>
  </div>
  <?php if(isset($_SESSION['status']) && $_SESSION['status']!=''){ ?>
  <script>
Swal.fire({
icon: '<?php echo $_SESSION['icon'] ?>',
title: '<?php echo $_SESSION['status'] ?>',
showCloseButton: true,
confirmButton: true,

})
</script>
<?php
unset($_SESSION['status']);
unset($_SESSION['icon']);
session_destroy();
}?>
</body>
</html>