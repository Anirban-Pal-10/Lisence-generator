<?php
include "../include/_session.php";
include "../include/_db_connect.php";
date_default_timezone_set("Asia/Calcutta");
$current_date=date("d-M-Y");
$current_time=date("H:i:s");
$current_month = date("M");
$current_Year = date("Y");
$current_date_time=$current_date." - ".$current_time;


//date Encription
function date_modifi($get_date){
    $t_1 = substr($get_date, 8, 2);    //days
    $t_2 = substr($get_date, 5, 2); //month
    $t_3 = substr($get_date, 0, 4); //year

    $date_marge =  $t_3.$t_2.$t_1;
    $date_mod = ($date_marge * 7);
    $length = strlen($date_mod);
    if($length<9){
        for($i=$length; $i<9; $i++){
            $date_mod = "0".$date_mod;

        }

    }
       
    return($date_mod);
}

//date Decription
function date_simplifi($get_date){

    $date_mod = "";
    $length = strlen($get_date);
    if($length<9){
        $date_mod = ($get_date / 7);
        
    }
    $t_1 = substr($date_mod, 8, 2); //days
    $t_2 = substr($date_mod, 5, 2); //month
    $t_3 = substr($date_mod, 0, 4); //year
    $date_marge =  $t_3."-".$t_2."-".$t_1;  
    return($date_marge);
}

//user encription
function user_modifi($user){
    $addition_formate = $user+57;
    $mult_formate = $addition_formate*12;
    $length = strlen($mult_formate);
  
    if($length<6){
        for($i=$length; $i<6; $i++){
            $mult_formate = "0".$mult_formate;
        }
    }
    return($mult_formate);
}

// user decription
function user_simplifi($user){
    $total_user = "";
    $length = strlen($user);
  
    if($length<6){
        $division_formate = $user/12;
        $total_user = $division_formate-57;
    }
  
    return($total_user);
  }



function key_generate($users, $date, $mac){
    $user_mod = user_modifi($users);
    $date_mod = date_modifi($date);
    $mac_id = $mac;

    $code = "BT".substr($mac_id,0,2)."-".substr($date_mod,0,2).substr($mac_id, 15,2)."-".substr($date_mod,2,2).substr($mac_id,3,2)."-".substr($date_mod,4,2).substr($mac_id,12,2)."-".substr($user_mod,0,2).substr($mac_id,6,2)."-".substr($user_mod,2,2).substr($mac_id,9,2)."-".substr($user_mod,4,2).substr($date_mod,6,2)."-".substr($date_mod,8,2);
    // "BT + 1,2 mac" - "1,2 modified date + 16,17 mac" - "3,4 of modified date + 4,5 of mac" - "5,6 of modified date + 13,14 of mac " - "1,2 of modified user + 7,9 of mac" - "3,4 of modified user + 11,12 of mac" - "5,6 of modified user +   7,8 of modified date" - "9 of modified date"
    return($code);

}

if(isset($_POST['key_gen'])){
    $co_name = $_POST['co_name'];
    $qut_user= $_POST['qunt_user'];
    $exp_date = $_POST['exp_date'];
    $mac_id = $_POST['mac_id'];
    $expiremonth = date("M", strtotime($exp_date));
    $expireyear = date("Y", strtotime($exp_date));

    if($co_name!="" && $qut_user!="" && $exp_date!="" && $mac_id!=""){
        if(strlen($mac_id)==17){
            if(substr($mac_id,2,1)=="-" && substr($mac_id,5,1)=="-" && substr($mac_id,8,1)=="-" && substr($mac_id,11,1)=="-" && substr($mac_id,14,1)=="-"){
                echo "yes";
                $key = key_generate($qut_user, $exp_date, $mac_id);


                // $key_no_of_row = mysqli_num_rows(mysqli_query($conn,"select * from `activation key`")) ;
                $keyid = "K-".time();
                $log_id = $_SESSION['user_id'];

                $insert_query = mysqli_query($conn,"insert into `activation key`(`key_id`, `company_name`, `generate_by`, `Activation_key`, `no_of_user`, `generate_date`, `generate_month`, `generate_year`, `expire_date`, `expire_month`, `expire_year`, `status`) values ('$keyid','$co_name','$log_id','$key','$qut_user',CURDATE(),'$current_month','$current_Year','$exp_date','$expiremonth','$expireyear','Active')");
                 if($insert_query){
                    $_SESSION['icon']='success';
                    $_SESSION['status']='your Activation Key '.$key;
                
                    header("location:key_gen.php");
                 } else{
                    $_SESSION['icon']='error';
                    $_SESSION['status']='Activation Key Not Generated';
                
                     header("location:key_gen.php");
                 }  
                // echo $key;
            }else{
                $_SESSION['icon']='error';
                $_SESSION['status']='MAC Adress Invelid';
                
                header("location:key_gen.php");
            }
        } else{
            $_SESSION['icon']='error';
            $_SESSION['status']='MAC Adress Invelid';
            
            header("location:key_gen.php");
        }

    }else{
        $_SESSION['icon']='error';
        $_SESSION['status']='Invalid Input';
        
        header("location:key_gen.php");
    }

}

?>