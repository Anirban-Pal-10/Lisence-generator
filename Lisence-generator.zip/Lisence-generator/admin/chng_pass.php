<?php
include "../include/_session.php";
include "../include/_db_connect.php";
$log_id = $_SESSION['user_id'];

if(isset($_POST['chng_pass'])){
    $old_pass = $_POST['old_pass'];
    $new_pass = $_POST['new_pass'];

    $sql_user_data = mysqli_fetch_assoc(mysqli_query($conn,"select * from `user_details` where `user_id` = '$log_id'"));
    $db_pass = $sql_user_data['password'];
    if(password_verify($old_pass, $db_pass)){
        $new_password = password_hash($new_pass, PASSWORD_DEFAULT);
        $update_pass= mysqli_query($conn,"update `user_details` set `password`='$new_password' where `user_id` = '$log_id'");
        if($update_pass){
            $_SESSION['icon'] = 'success';
            $_SESSION['status']='Password Change Successfully';
            // header("location:chng_pass.php");
        }else{
            $_SESSION['icon'] = 'error';
            $_SESSION['status']='Password Change not Done';
        }

    }else{
        $_SESSION['icon'] = 'error';
        $_SESSION['status']='Invalid Old Password';
    }
}



?>


<!DOCTYPE html>
<html lang="en">

<?php include "include/head.php";?>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include "include/header_mob.php";?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php include "include/menu.php";?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include "include/header.php";?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content" >
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <form action="" method="post">

                        <div class="card" style="margin-bottom:10px;">
                            <h5 class="card-header" style="padding-bottom:.8rem;    font-family: 'Prosto One', cursive;">Change Password</h5>
                            <!-- <?php
                                // $string=exec('getmac');
                                // $mac=substr($string, 0, 17); 
                                // echo $mac;
                                ?> -->
                            <div class="card-body">
                                <!-- <div class="row"> -->


                                        <div class="mb-3 col-md-6">
                                            <label for="firstName" class="form-label">Old Password</label>
                                            <input type="password" class="form-control" placeholder="Enter Old Password"
                                            style="    width: 100%;  " id="myInput" name="old_pass"  required>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="firstName" class="form-label">New Password </label>
                                        <input type="password" class="form-control" placeholder="Enter New Password"
                                            style="    width: 100%;  " id="myInput" name="new_pass"  required>

                                    </div>
                                    
                                    <div class="mb-3 col-md-6" style="    display: flex; place-content: end;">
                                            <button class="btn btn-primary me-2" name="chng_pass" style="">Change Password</button>
                                        <!-- <Button type="button"class="btn btn-primary" id ="dev_no"> View Device Number</Button> -->
                                        <!-- <input type="button" name="save" value='Update Key'> -->
                                        <!-- <button  class="btn btn-primary me-2" name="save"></button> -->
                                        <!-- <button type="reset" class="btn btn-outline-secondary">Cancel</button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->
    </div>

    </div>

    <?php include "include/footer.php";?>
    <?php if(isset($_SESSION['status']) && $_SESSION['status']!=''){ ?>
            <script>
      Swal.fire({
      icon: '<?php echo $_SESSION['icon'] ?>',
      title: '<?php echo $_SESSION['status'] ?>',
      showCloseButton: true,
      confirmButton: true,
      
    })
    </script>
    <?php
    unset($_SESSION['status']);
    unset($_SESSION['icon']);
      }?>
</body>

</html>
<!-- end document-->