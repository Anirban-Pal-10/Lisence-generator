<?php
include "../include/_session.php";
include "../include/_db_connect.php";
$month = ['January', 'February', 'March', 'April', 'May', 'June', 'July ', 'August', 'September', 'October', 'November', 'December'];

$short = array('Jan', 'Feb',  'Mar',  'Apr',  'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' );



?>


<!DOCTYPE html>
<html lang="en">

<?php include "include/head.php";?>

<body class="animsition">
   <div class="page-wrapper">
      <!-- HEADER MOBILE-->
      <?php include "include/header_mob.php";?>
      <!-- END HEADER MOBILE-->

      <!-- MENU SIDEBAR-->
      <?php include "include/menu.php";?>
      <!-- END MENU SIDEBAR-->

      <!-- PAGE CONTAINER-->
      <div class="page-container">
         <!-- HEADER DESKTOP-->
         <?php include "include/header.php";?>
         <!-- HEADER DESKTOP-->

         <!-- MAIN CONTENT-->
         <div class="main-content">
            <div class="section__content section__content--p30">
               <div class="container-fluid">
                  <div class="card" style="margin-bottom:10px;">
                     <h5 class="card-header"
                        style="padding-bottom:.8rem;    font-family: 'Prosto One', cursive;">Log Report
                     </h5>
                     <?php
                        $string=exec('getmac');
                        $mac=substr($string, 0, 17); 
                        // echo $mac;
                        // echo $fdate ."////////".$tdate; 
                        ?>
                     <div class="card-body">
                         <form action="report_process.php" method="post">
                        <div class="row">

                                <div class="mb-3 col-md-6" style="display:flex;place-items: center;column-gap: 15px;" id="logmonth">
                                    <label for="firstName" class="form-label" style="margin-right:4.2%;">Date</label>
                                    <input type="date" class="form-control" placeholder="dd-mm-yyyy"style=" margin-bottom:2%;   width: 100%;  " id="d1" name="fd">
                                    <input type="date" class="form-control" placeholder="dd-mm-yyyy"style=" margin-bottom:2%;   width: 100%;  " id="d2" name="td">
    
                                  
                               </div>
                               <div class="mb-3 col-md-6">
                                   <button class="btn btn-primary me-2" name="date_report" style="margin-right:1%" id="g1">Generate Report</button>
                               </div>
                               </div>
                            </form>
                            <form action="report_process.php" method="post">
                              <div class="row">
                                 <div class="mb-3 col-md-6" style="display:flex;place-items: center;column-gap: 15px;" id="logmonth">
                                    <label for="firstName" class="form-label">Monthly</label>
                                    <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="m1" name="lm">

                                       <option value="" disabled selected hidden>Select month</option>
                                       <?php for($i = 0; $i<count($month); $i++){?>
                                       <option value="<?php echo $short[$i];?>"><?php echo $month[$i];?></option>
                                       <?php } ?>
                                    </select>
                                    <select class="form-control" style="    width: 100%;  margin-bottom:5px;" id="y1" name="ly">
                                       <option value="" disabled selected hidden>Select Year</option>
                                       <?php for($i = date("Y"); $i>=2020; $i--){?>
                                       <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                                 <div class="mb-3 col-md-6">
                                    <button class="btn btn-primary me-2" name="monthly_report" style="margin-right:1%" id = "g2">Generate Report</button>
                                 </div>
                              
                              </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>

               <!-- END MAIN CONTENT-->
               <!-- END PAGE CONTAINER-->


               <?php include "include/footer.php";?>
</body>


</html>
<!-- end document-->
<script>
   $("#g1").prop("disabled", true);
   $("#g2").prop("disabled", true);
   $("#d1, #d1").change(function(){
      $("#m1").val('');
      $("#y1").val('');
      $("#g2").prop("disabled", true);
      let v1 = "", v2="";
      v1 = new Date($('#d1').val());
      v2 = new Date($('#d2').val());
      if(v1.getDate()!="NaN" && v2.getDate()!="NaN"){
        console.log(v2.getDate());
        console.log(v1.getDate());
         $("#g1").prop("disabled", false);

      }
   })
   $("#m1, #y1").change(function(){
      $("#d1").val('');
      $("#d2").val('');
      $("#g1").prop("disabled", true);
      let v1 = "", v2="";
      v1 = $("#m1").val();
      v2 = $("#y1").val();
      if(v1!=null && v2!=null){
         $("#g2").prop("disabled", false);

      }
   })
</script>