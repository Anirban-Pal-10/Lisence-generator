<?php
include "../include/_session.php";
include "../include/_db_connect.php";


?>


<!DOCTYPE html>
<html lang="en">

<?php include "include/head.php";?>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include "include/header_mob.php";?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php include "include/menu.php";?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include "include/header.php";?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content" >
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <form action="key_process.php" method="post">

                        <div class="card" style="margin-bottom:10px;">
                            <h5 class="card-header" style="padding-bottom:.8rem;    font-family: 'Prosto One', cursive;">Generate License</h5>
                            <!-- <?php
                                // $string=exec('getmac');
                                // $mac=substr($string, 0, 17); 
                                // echo $mac;
                                ?> -->
                            <div class="card-body">
                                <div class="row">


                                        <div class="mb-3 col-md-6">
                                            <label for="firstName" class="form-label">Company Name</label>
                                            <input type="text" class="form-control" placeholder="Enter Company Name"
                                            style="    width: 100%;  " id="myInput" name="co_name"  required>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="firstName" class="form-label">No of Users </label>
                                        <input type="text" class="form-control" placeholder="Enter No of Users"
                                            style="    width: 100%;  " id="myInput" name="qunt_user"  required>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="firstName" class="form-label">Expiry Date </label>
                                        <input type="date" class="form-control" placeholder="dd-mm-yyyy"style="    width: 100%;  " id="myInput" name="exp_date"  required>

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label for="firstName" class="form-label">Server MAC Id  (with  "-") </label>
                                        <input type="text" class="form-control" placeholder="##-##-##-##-##-##"
                                            style="    width: 100%;  " id="myInput" maxlength="17" name="mac_id" required>

                                    </div>
                                </div>
                                <div class="mt-2" style="place-content: end;    display: flex;">
                                    <!-- <Button type="button"class="btn btn-primary" id ="dev_no"> View Device Number</Button> -->
                                    <button class="btn btn-primary me-2" name="key_gen" style="margin-right:1%">Generate
                                        Key</button>
                                    <!-- <input type="button" name="save" value='Update Key'> -->
                                    <!-- <button  class="btn btn-primary me-2" name="save"></button> -->
                                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </form>
                        <div class="mb-3 col-md-6" style="display:flex;place-items: center; " id="logmonth">
                            <label for="firstName" class="form-label">Quick Search</label>
                            <input type="text" class="form-control" placeholder="Search by Company Name" style="width: 50%;margin-left:5%" id="myInput1" onkeyup="quickSearch()">

                        </div>
                        <div class="card"style="height: 250px; border-radius:10px;">
                            <div class="card-body" style="padding-bottom:.5rem;padding:0px;">
                                <div class="table-responsive table--no-card m-b-30" style="height:80%">
                                    <table class="table table-borderless table-striped table-earning" id="myTable">
                                        <thead style="position:sticky; top:0px;">
                                            <tr>
                                                <th>Sl NO</th>
                                                <th>Comapny Name</th>
                                                <th>No Of User</th>
                                                <th>Key</th>
                                                <th>Generate Date</th>
                                                <th>Expiry Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i=0;
                                                $sql_for_key_details = mysqli_query($conn,"select * from `activation key`order by `sl_no` desc;") ;
                                                while($key_details = mysqli_fetch_assoc($sql_for_key_details)){$i++;?>
                                            <tr>
                                                <td><?php echo $i?></td>
                                                <td><?php echo $key_details['company_name'];?></td>
                                                <td><?php echo $key_details['no_of_user'];?></td>
                                                <td><?php echo $key_details['Activation_key'];?></td>
                                                <td><?php echo date("d-M-Y", strtotime($key_details['generate_date'])) ;?></td>
                                                <td><?php echo date("d-M-Y", strtotime($key_details['expire_date']));?></td>
                                            </tr>
                                          <?php }?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>






                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->
    </div>

    </div>

    <?php include "include/footer.php";?>
    <?php if(isset($_SESSION['status']) && $_SESSION['status']!=''){ ?>
            <script>
      Swal.fire({
      icon: '<?php echo $_SESSION['icon'] ?>',
      title: '<?php echo $_SESSION['status'] ?>',
      showCloseButton: true,
      confirmButton: true,
      
    })
    </script>
    <?php
    unset($_SESSION['status']);
    unset($_SESSION['icon']);
      }?>
</body>
<script>
function quickSearch() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  console.log(filter);
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</html>
<!-- end document-->