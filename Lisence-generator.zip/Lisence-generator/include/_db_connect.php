<?php
     $server ="localhost";
     $username ="root";
     $password ="";
     $db_lg ="key_generate";    
     $conn = mysqli_connect($server, $username, $password, $db_lg);
     if(!$conn){
          die("error" . mysqli_connect_error());
     }    

?>